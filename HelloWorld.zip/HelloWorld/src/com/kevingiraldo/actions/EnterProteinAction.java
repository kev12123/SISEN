package com.kevingiraldo.actions;

import com.opensymphony.xwork2.ActionSupport;

public class EnterProteinAction extends ActionSupport {
    
	private int enteredProtein;
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		ProteinTrackingService pt = new ProteinTrackingService();
		pt.addProtein(enteredProtein);
		return SUCCESS;
	}
	public int getEnteredProtein() {
		return enteredProtein;
	}
	public void setEnteredProtein(int enteredProtein) {
		this.enteredProtein = enteredProtein;
	}
    
	
	public String getGoalText(){
		
		return getText("goal.text");
	}
}
