package com.kevingiraldo.actions;
import com.opensymphony.xwork2.Action;


public class HelloAction implements Action {
	
	
	private String greeting;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		setGreeting("Hello Struts !!!");
		return "success";
	}
	
	public String getGreeting(){
		
		return this.greeting;
	}
	
	public void setGreeting(String newGreeting){
		
		this.greeting = newGreeting;
	}

}
