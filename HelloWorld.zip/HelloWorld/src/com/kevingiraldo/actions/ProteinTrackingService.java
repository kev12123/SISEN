package com.kevingiraldo.actions;

public class ProteinTrackingService {
	
	public void addProtein(int protein){
		
		
	}

}
