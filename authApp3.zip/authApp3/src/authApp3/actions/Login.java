package authApp3.actions;

import java.util.Map;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class Login extends ActionSupport implements SessionAware{
    
	private String username;
	private String userpass;
	private Map<String, Object> session;
	
	
	@Action("login-input")
	public String input(){
		
		return "login";
	}
	
	@Override
	@Action("login")
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		
		if(LoginDao.validate(username,userpass)){
			session.put("login", "true");
			return SUCCESS;
		}
		else{
			return ERROR;
		
		}
	}

	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.session = session;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpass() {
		return userpass;
	}

	public void setUserpass(String userpass) {
		this.userpass = userpass;
		session.put("login", "true");
	}

}
