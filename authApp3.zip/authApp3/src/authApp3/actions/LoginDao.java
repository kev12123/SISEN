package authApp3.actions;


import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


public class LoginDao {
	
	public static boolean validate(String username , String password){
		
		if(username.equals("test") && password.equals("test"))
			return true;
		else
			return false;
			
		
		
	}

}
